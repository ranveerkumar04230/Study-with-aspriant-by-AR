const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write batches, subjects, lectures, or settings", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const ts = new Date(Date.now() - 1000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("batches").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("subjects").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("lectures").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("settings").doc("preferences").get());

  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("batches").doc("b1").set({
      userId: ALICE_UID,
      name: "PARMAR 4.0",
      subtitle: "GK GS",
      sortOrder: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Authenticated owner: valid Kotlin batch, subject, lecture, and preferences CRUD + WriteBatch seed succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const updated = new Date(Date.now() - 1000);

  // Atomic WriteBatch seed matching StudyRepository.seedDefaultDataIfEmpty
  const batch = aliceDb.batch();
  const batchRef = aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("parmar_4_0");
  const subjectRef = aliceDb.collection("users").doc(ALICE_UID).collection("subjects").doc("parmar_biology");
  const prefsRef = aliceDb.collection("users").doc(ALICE_UID).collection("settings").doc("preferences");

  batch.set(batchRef, {
    userId: ALICE_UID,
    name: "PARMAR 4.0",
    subtitle: "BY PARMAR SIR • GK & GS COMPLETE",
    sortOrder: 0,
    createdAt: created,
    updatedAt: created,
  });

  batch.set(subjectRef, {
    userId: ALICE_UID,
    batchId: "parmar_4_0",
    name: "BIOLOGY",
    sortOrder: 0,
    createdAt: created,
    updatedAt: created,
  });

  batch.set(prefsRef, {
    userId: ALICE_UID,
    whatsappUrl: "https://whatsapp.com",
    telegramUrl: "https://telegram.org",
    seededDefaults: true,
    createdAt: created,
    updatedAt: created,
  });

  await assertSucceeds(batch.commit());

  // Create lecture referencing valid batch & subject (NO @DocumentId `id` field)
  const lectureRef = aliceDb.collection("users").doc(ALICE_UID).collection("lectures").doc("lec_1");
  await assertSucceeds(
    lectureRef.set({
      userId: ALICE_UID,
      batchId: "parmar_4_0",
      subjectId: "parmar_biology",
      title: "CELL - LEC 1",
      videoUrl: "https://youtube.com/watch?v=dQw4w9WgXcQ",
      engNotesUrl: "https://drive.google.com/file/d/abc/view",
      hinNotesUrl: "",
      pptUrl: "",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Partial update: toggle completed
  await assertSucceeds(
    lectureRef.update({
      completed: true,
      updatedAt: updated,
    })
  );

  // Partial update: edit lecture details
  await assertSucceeds(
    lectureRef.update({
      title: "CELL - LEC 1 (REVISED)",
      videoUrl: "https://youtu.be/dQw4w9WgXcQ",
      engNotesUrl: "https://drive.google.com/file/d/abc/view",
      hinNotesUrl: "https://drive.google.com/file/d/hin/view",
      pptUrl: "https://drive.google.com/file/d/ppt/view",
      completed: true,
      updatedAt: updated,
    })
  );

  // Partial update: update social links & adminPasscodeHash
  await assertSucceeds(
    prefsRef.update({
      whatsappUrl: "https://wa.me/919876543210",
      telegramUrl: "https://t.me/studyaspirant",
      seededDefaults: true,
      adminPasscodeHash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      updatedAt: updated,
    })
  );

  // List queries (matching Kotlin repository snapshot queries)
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("batches").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("subjects").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("lectures").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("settings").doc("preferences").get());
});

test("Cross-user isolation: Bob cannot read or modify Alice's data", async () => {
  const created = new Date(Date.now() - 10000);
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(ALICE_UID).collection("batches").doc("b1").set({
      userId: ALICE_UID,
      name: "PARMAR 4.0",
      subtitle: "GK",
      sortOrder: 0,
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(ALICE_UID).collection("settings").doc("preferences").set({
      userId: ALICE_UID,
      whatsappUrl: "https://whatsapp.com",
      telegramUrl: "https://telegram.org",
      seededDefaults: true,
      createdAt: created,
      updatedAt: created,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("batches").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("batches").doc("b1").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("batches").doc("b1").update({
      name: "HACKED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("settings").doc("preferences").get());
});

test("Validation & security guards: reject ghost fields, extra @DocumentId, orphaned lectures, immutable edits, future timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("b1").set({
      userId: ALICE_UID,
      name: "PARMAR 4.0",
      subtitle: "GK",
      sortOrder: 0,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject extra `id` field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("b2").set({
      id: "b2",
      userId: ALICE_UID,
      name: "EXTRA ID",
      subtitle: "GK",
      sortOrder: 1,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("b3").set({
      userId: ALICE_UID,
      name: "GHOST",
      subtitle: "GK",
      sortOrder: 1,
      isAdmin: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("b4").set({
      userId: ALICE_UID,
      name: "FUTURE",
      subtitle: "GK",
      sortOrder: 1,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: created,
    })
  );

  // Reject immutable createdAt modification on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("batches").doc("b1").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject orphaned lecture pointing to non-existent subject/batch
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("lectures").doc("orphan_lec").set({
      userId: ALICE_UID,
      batchId: "nonexistent_batch",
      subjectId: "nonexistent_subject",
      title: "ORPHAN",
      videoUrl: "",
      engNotesUrl: "",
      hinNotesUrl: "",
      pptUrl: "",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject invalid settings document ID
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("settings").doc("other_doc").set({
      userId: ALICE_UID,
      whatsappUrl: "https://whatsapp.com",
      telegramUrl: "https://telegram.org",
      seededDefaults: false,
      createdAt: created,
      updatedAt: created,
    })
  );
});
