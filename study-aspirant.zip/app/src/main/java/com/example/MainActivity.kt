package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.auth.authStateFlow
import com.example.data.StudyRepository
import com.example.ui.StudyViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StudyPortalScreen
import com.example.ui.theme.StudyAspirantTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

const val ROUTE_SPLASH = "splash"
const val ROUTE_LOGIN = "login"
const val ROUTE_PORTAL = "portal"

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      StudyAspirantTheme {
        AppNavigation()
      }
    }
  }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
  val navController = rememberNavController()
  val currentUser by auth.authStateFlow()
    .collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val latestUser by rememberUpdatedState(currentUser)

  var pendingAdminPassword by remember { mutableStateOf<String?>(null) }

  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route

  LaunchedEffect(currentUser, currentRoute) {
    if (currentRoute == null || currentRoute == ROUTE_SPLASH) return@LaunchedEffect
    if (currentUser == null && currentRoute != ROUTE_LOGIN) {
      pendingAdminPassword = null
      navController.navigate(ROUTE_LOGIN) {
        popUpTo(0) { inclusive = true }
        launchSingleTop = true
      }
    } else if (currentUser != null && currentRoute != ROUTE_PORTAL) {
      navController.navigate(ROUTE_PORTAL) {
        popUpTo(0) { inclusive = true }
        launchSingleTop = true
      }
    }
  }

  NavHost(
    navController = navController,
    startDestination = ROUTE_SPLASH,
    enterTransition = { fadeIn() },
    exitTransition = { fadeOut() },
  ) {
    composable(ROUTE_SPLASH) {
      SplashScreen(
        onSplashFinished = {
          val target = if (latestUser == null) ROUTE_LOGIN else ROUTE_PORTAL
          navController.navigate(target) {
            popUpTo(ROUTE_SPLASH) { inclusive = true }
            launchSingleTop = true
          }
        },
      )
    }

    composable(ROUTE_LOGIN) {
      AuthScreen(
        onAdminAuthSuccess = { adminPassword ->
          pendingAdminPassword = adminPassword
        },
        onAuthSuccess = {
          pendingAdminPassword = null
        },
      )
    }

    composable(ROUTE_PORTAL) {
      val user = currentUser
      if (user != null) {
        key(user.uid) {
          val studyViewModel: StudyViewModel = viewModel(
            key = user.uid,
            factory = viewModelFactory {
              initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                  "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StudyViewModel(
                  repository = StudyRepository(db),
                  currentUserId = user.uid,
                )
              }
            },
          )

          LaunchedEffect(user.uid, pendingAdminPassword) {
            val pending = pendingAdminPassword
            if (!pending.isNullOrBlank()) {
              pendingAdminPassword = null
              studyViewModel.verifyPendingAdminPassword(pending)
            }
          }

          val contactLabel = user.phoneNumber?.takeIf { it.isNotBlank() } ?: user.email
          StudyPortalScreen(
            viewModel = studyViewModel,
            userContactLabel = contactLabel,
          )
        }
      }
    }
  }
}
