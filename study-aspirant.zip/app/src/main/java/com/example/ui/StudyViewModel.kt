package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StudyRepository
import com.example.data.model.AppPreferences
import com.example.data.model.StudyBatch
import com.example.data.model.StudyLecture
import com.example.data.model.StudySubject
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

data class StudyWorkspaceData(
  val batches: List<StudyBatch> = emptyList(),
  val subjects: List<StudySubject> = emptyList(),
  val lectures: List<StudyLecture> = emptyList(),
  val preferences: AppPreferences = AppPreferences(),
)

enum class SyncStatus {
  CONNECTING,
  LIVE_SYNCED,
  ERROR,
}

class StudyViewModel(
  private val repository: StudyRepository,
  private val currentUserId: String,
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _isAdminUnlocked = MutableStateFlow(false)
  val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

  private val _isAdminSheetOpen = MutableStateFlow(false)
  val isAdminSheetOpen: StateFlow<Boolean> = _isAdminSheetOpen.asStateFlow()

  private val _isSavingAdmin = MutableStateFlow(false)
  val isSavingAdmin: StateFlow<Boolean> = _isSavingAdmin.asStateFlow()

  private val _syncStatus = MutableStateFlow(SyncStatus.CONNECTING)
  val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

  private val _toastMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
  val toastMessages: SharedFlow<String> = _toastMessages.asSharedFlow()

  private var seedAttempted = false

  val workspaceState: StateFlow<UiState<StudyWorkspaceData>> =
    combine(
      repository.observeBatches(currentUserId),
      repository.observeSubjects(currentUserId),
      repository.observeLectures(currentUserId),
      repository.observePreferences(currentUserId),
    ) { batches, subjects, lectures, prefs ->
      if (!seedAttempted && (prefs == null || !prefs.seededDefaults)) {
        seedAttempted = true
        launchSeedIfNeeded()
      }
      _syncStatus.value = SyncStatus.LIVE_SYNCED
      UiState.Success(
        StudyWorkspaceData(
          batches = batches,
          subjects = subjects,
          lectures = lectures,
          preferences = prefs ?: AppPreferences(),
        )
      ) as UiState<StudyWorkspaceData>
    }
      .catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
          .filterIsInstance<FirebaseFirestoreException>()
          .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing study workspace", rootError)
        _syncStatus.value = SyncStatus.ERROR
        emit(UiState.Error(rootError.localizedMessage ?: "Failed to sync study data"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  private fun launchSeedIfNeeded() {
    viewModelScope.launch {
      val result = repository.seedDefaultDataIfEmpty(currentUserId)
      result.onFailure { err ->
        Log.w(TAG, "Default batch seed failed", err)
        _toastMessages.tryEmit(err.localizedMessage ?: "Could not initialize default batches.")
      }
    }
  }

  fun onSearchQueryChange(newQuery: String) {
    _searchQuery.value = newQuery
  }

  fun clearSearch() {
    _searchQuery.value = ""
  }

  fun verifyPendingAdminPassword(password: String) {
    viewModelScope.launch {
      val result = repository.verifyOrSetAdminPassword(
        userId = currentUserId,
        passwordInput = password,
        configuredSecretPassword = "",
      )
      result.fold(
        onSuccess = { matched ->
          if (matched) {
            _isAdminUnlocked.value = true
            _isAdminSheetOpen.value = true
            _toastMessages.tryEmit("🔓 Admin login successful")
          } else {
            _isAdminUnlocked.value = false
            _toastMessages.tryEmit("Incorrect Admin Password for this account.")
          }
        },
        onFailure = { err ->
          _toastMessages.tryEmit(err.localizedMessage ?: "Failed to verify Admin Password")
        },
      )
    }
  }

  fun openAdminSheetIfUnlocked() {
    if (_isAdminUnlocked.value) {
      _isAdminSheetOpen.value = true
    }
  }

  fun closeAdminSheet() {
    _isAdminSheetOpen.value = false
  }

  fun saveLecture(
    batchName: String,
    batchSubtitle: String,
    subjectName: String,
    lectureTitle: String,
    videoUrl: String,
    engNotesUrl: String,
    hinNotesUrl: String,
    pptUrl: String,
    onSuccess: () -> Unit,
  ) {
    val currentData = (workspaceState.value as? UiState.Success)?.data ?: StudyWorkspaceData()
    if (batchName.isBlank() || subjectName.isBlank() || lectureTitle.isBlank()) {
      _toastMessages.tryEmit("Batch, Subject और Lecture नाम ज़रूरी हैं!")
      return
    }
    viewModelScope.launch {
      _isSavingAdmin.value = true
      val result = repository.saveLectureWithBatchAndSubject(
        userId = currentUserId,
        batchNameInput = batchName,
        batchSubtitleInput = batchSubtitle,
        subjectNameInput = subjectName,
        lectureTitleInput = lectureTitle,
        videoUrlInput = videoUrl,
        engNotesUrlInput = engNotesUrl,
        hinNotesUrlInput = hinNotesUrl,
        pptUrlInput = pptUrl,
        currentBatches = currentData.batches,
        currentSubjects = currentData.subjects,
      )
      _isSavingAdmin.value = false
      result.fold(
        onSuccess = {
          _toastMessages.tryEmit("✅ लेक्चर सेव हो गया!")
          _isAdminSheetOpen.value = false
          onSuccess()
        },
        onFailure = { err ->
          _toastMessages.tryEmit(err.localizedMessage ?: "Failed to save lecture")
        },
      )
    }
  }

  fun saveSocialLinks(whatsappInput: String, telegramInput: String) {
    viewModelScope.launch {
      _isSavingAdmin.value = true
      val result = repository.saveSocialLinks(currentUserId, whatsappInput, telegramInput)
      _isSavingAdmin.value = false
      result.fold(
        onSuccess = {
          _toastMessages.tryEmit("✅ लिंक्स अपडेट हो गए!")
          _isAdminSheetOpen.value = false
        },
        onFailure = { err ->
          _toastMessages.tryEmit(err.localizedMessage ?: "Failed to save links")
        },
      )
    }
  }

  fun toggleLectureCompleted(lecture: StudyLecture) {
    viewModelScope.launch {
      val result = repository.toggleLectureCompleted(
        userId = currentUserId,
        lectureId = lecture.id,
        completed = !lecture.completed,
      )
      result.onFailure { err ->
        _toastMessages.tryEmit(err.localizedMessage ?: "Failed to update lecture status")
      }
    }
  }

  fun deleteLecture(lectureId: String) {
    viewModelScope.launch {
      val result = repository.deleteLecture(currentUserId, lectureId)
      result.fold(
        onSuccess = { _toastMessages.tryEmit("Lecture removed") },
        onFailure = { err ->
          _toastMessages.tryEmit(err.localizedMessage ?: "Failed to delete lecture")
        },
      )
    }
  }

  private companion object {
    const val TAG = "StudyVM"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
