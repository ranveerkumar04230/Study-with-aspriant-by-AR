package com.example.auth

import android.app.Activity
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

private const val TAG = "PhoneAuth"

fun formatPhoneNumberE164(rawInput: String): String {
  val trimmed = rawInput.trim()
  if (trimmed.startsWith("+")) {
    val digits = trimmed.substring(1).filter { it.isDigit() }
    return "+$digits"
  }
  val digitsOnly = trimmed.filter { it.isDigit() }
  return when {
    digitsOnly.length == 10 -> "+91$digitsOnly"
    digitsOnly.length > 10 && digitsOnly.startsWith("91") -> "+$digitsOnly"
    digitsOnly.isNotEmpty() -> "+$digitsOnly"
    else -> ""
  }
}

fun isValidPhoneNumberInput(rawInput: String): Boolean {
  val formatted = formatPhoneNumberE164(rawInput)
  val digits = formatted.removePrefix("+")
  return formatted.startsWith("+") && digits.length in 10..15
}

fun startPhoneNumberVerification(
  activity: Activity,
  formattedPhone: String,
  resendToken: PhoneAuthProvider.ForceResendingToken? = null,
  onAutoVerified: () -> Unit,
  onCodeSent: (verificationId: String, token: PhoneAuthProvider.ForceResendingToken) -> Unit,
  onError: (String) -> Unit,
) {
  val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
      Firebase.auth.signInWithCredential(credential)
        .addOnSuccessListener { onAutoVerified() }
        .addOnFailureListener { e ->
          Log.e(TAG, "Auto phone verification sign-in failed", e)
          onError(mapPhoneAuthException(e))
        }
    }

    override fun onVerificationFailed(e: FirebaseException) {
      Log.e(TAG, "Phone verification failed", e)
      onError(mapPhoneAuthException(e))
    }

    override fun onCodeSent(
      verificationId: String,
      token: PhoneAuthProvider.ForceResendingToken,
    ) {
      onCodeSent(verificationId, token)
    }
  }

  val builder = PhoneAuthOptions.newBuilder(Firebase.auth)
    .setPhoneNumber(formattedPhone)
    .setTimeout(60L, TimeUnit.SECONDS)
    .setActivity(activity)
    .setCallbacks(callbacks)

  if (resendToken != null) {
    builder.setForceResendingToken(resendToken)
  }

  PhoneAuthProvider.verifyPhoneNumber(builder.build())
}

suspend fun verifyOtpAndSignIn(
  verificationId: String,
  otpCode: String,
): Result<Unit> {
  return try {
    val cleanOtp = otpCode.trim()
    require(cleanOtp.length == 6 && cleanOtp.all { it.isDigit() }) {
      "Please enter the 6-digit OTP sent to your phone."
    }
    val credential = PhoneAuthProvider.getCredential(verificationId, cleanOtp)
    Firebase.auth.signInWithCredential(credential).await()
    Result.success(Unit)
  } catch (e: Exception) {
    Log.e(TAG, "OTP verification failed", e)
    Result.failure(Exception(mapPhoneAuthException(e), e))
  }
}

private fun mapPhoneAuthException(e: Exception): String {
  if (e is FirebaseAuthException) {
    val code = e.errorCode
    if (code.contains("OPERATION_NOT_ALLOWED", ignoreCase = true) ||
      e.message?.contains("operation-not-allowed", ignoreCase = true) == true ||
      e.message?.contains("not allowed", ignoreCase = true) == true
    ) {
      return "Phone OTP login is not enabled yet in Firebase Console. Enable Authentication → Sign-in method → Phone for this project."
    }
    if (code.contains("INVALID_VERIFICATION_CODE", ignoreCase = true)) {
      return "Invalid OTP code. Please check the 6-digit code and try again."
    }
    if (code.contains("TOO_MANY_REQUESTS", ignoreCase = true) ||
      code.contains("QUOTA_EXCEEDED", ignoreCase = true)
    ) {
      return "Too many OTP requests right now. Please wait a bit and try again."
    }
  }
  return e.localizedMessage ?: "Phone verification failed. Please try again."
}
