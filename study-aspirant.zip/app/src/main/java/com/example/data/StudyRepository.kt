package com.example.data

import android.content.Context
import com.example.R
import com.example.data.model.AppPreferences
import com.example.data.model.DefaultSeedData
import com.example.data.model.StudyBatch
import com.example.data.model.StudyLecture
import com.example.data.model.StudySubject
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudyRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private fun requireUserId(expectedUserId: String): String {
    val uid = auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    check(uid.isNotBlank() && uid == expectedUserId) {
      "Signed-in user changed; refusing cross-user operation."
    }
    return uid
  }

  fun observeBatches(userId: String): Flow<List<StudyBatch>> = flow {
    val uid = requireUserId(userId)
    val path = "users/$uid/batches"
    emitAll(
      db.collection("users").document(uid).collection("batches")
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(
            StudyBatch::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          ).sortedWith(compareBy<StudyBatch> { it.sortOrder }.thenBy { it.name })
        }
        .catch { error ->
          logFlowError(error, OperationType.LIST, path, uid)
          throw error
        }
    )
  }

  fun observeSubjects(userId: String): Flow<List<StudySubject>> = flow {
    val uid = requireUserId(userId)
    val path = "users/$uid/subjects"
    emitAll(
      db.collection("users").document(uid).collection("subjects")
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(
            StudySubject::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          ).sortedWith(compareBy<StudySubject> { it.sortOrder }.thenBy { it.name })
        }
        .catch { error ->
          logFlowError(error, OperationType.LIST, path, uid)
          throw error
        }
    )
  }

  fun observeLectures(userId: String): Flow<List<StudyLecture>> = flow {
    val uid = requireUserId(userId)
    val path = "users/$uid/lectures"
    emitAll(
      db.collection("users").document(uid).collection("lectures")
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(
            StudyLecture::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          ).sortedBy { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
        }
        .catch { error ->
          logFlowError(error, OperationType.LIST, path, uid)
          throw error
        }
    )
  }

  fun observePreferences(userId: String): Flow<AppPreferences?> = flow {
    val uid = requireUserId(userId)
    val path = "users/$uid/settings/preferences"
    emitAll(
      db.collection("users").document(uid).collection("settings").document("preferences")
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(
              AppPreferences::class.java,
              DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            )
          } else {
            null
          }
        }
        .catch { error ->
          logFlowError(error, OperationType.GET, path, uid)
          throw error
        }
    )
  }

  suspend fun seedDefaultDataIfEmpty(userId: String): Result<Boolean> {
    val userDocPath = "users/$userId"
    return try {
      val uid = requireUserId(userId)
      val userRef = db.collection("users").document(uid)
      val prefsRef = userRef.collection("settings").document("preferences")
      val prefsSnap = prefsRef.get().await()
      if (prefsSnap.exists() && prefsSnap.getBoolean("seededDefaults") == true) {
        return Result.success(false)
      }

      val existingBatches = userRef.collection("batches").limit(1).get().await()
      val batchWrite = db.batch()
      if (existingBatches.isEmpty) {
        DefaultSeedData.batches.forEachIndexed { batchIndex, batchSpec ->
          val batchRef = userRef.collection("batches").document(batchSpec.id)
          batchWrite.set(
            batchRef,
            mapOf(
              "userId" to uid,
              "name" to batchSpec.name,
              "subtitle" to batchSpec.subtitle,
              "sortOrder" to batchIndex.toLong(),
              "createdAt" to FieldValue.serverTimestamp(),
              "updatedAt" to FieldValue.serverTimestamp(),
            ),
          )
          batchSpec.subjects.forEachIndexed { subIndex, subName ->
            val subSlug = "${batchSpec.id}_${slugify(subName)}"
            val subRef = userRef.collection("subjects").document(subSlug)
            batchWrite.set(
              subRef,
              mapOf(
                "userId" to uid,
                "batchId" to batchSpec.id,
                "name" to subName,
                "sortOrder" to subIndex.toLong(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              ),
            )
          }
        }
      }

      if (!prefsSnap.exists()) {
        batchWrite.set(
          prefsRef,
          mapOf(
            "userId" to uid,
            "whatsappUrl" to "https://whatsapp.com",
            "telegramUrl" to "https://telegram.org",
            "seededDefaults" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      } else {
        batchWrite.update(
          prefsRef,
          mapOf(
            "seededDefaults" to true,
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }

      batchWrite.commit().await()
      Result.success(true)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "$userDocPath/batches")
      Result.failure(e)
    }
  }

  suspend fun saveLectureWithBatchAndSubject(
    userId: String,
    batchNameInput: String,
    batchSubtitleInput: String,
    subjectNameInput: String,
    lectureTitleInput: String,
    videoUrlInput: String,
    engNotesUrlInput: String,
    hinNotesUrlInput: String,
    pptUrlInput: String,
    currentBatches: List<StudyBatch>,
    currentSubjects: List<StudySubject>,
  ): Result<Unit> {
    var opPath = "users/$userId/lectures"
    return try {
      val uid = requireUserId(userId)
      val batchName = batchNameInput.trim().uppercase()
      val batchSubtitle = batchSubtitleInput.trim().uppercase().ifBlank { "COMPLETE BATCH" }
      val subjectName = subjectNameInput.trim().uppercase()
      val lectureTitle = lectureTitleInput.trim().uppercase()
      val videoUrl = videoUrlInput.trim()
      val engNotesUrl = engNotesUrlInput.trim()
      val hinNotesUrl = hinNotesUrlInput.trim()
      val pptUrl = pptUrlInput.trim()

      require(batchName.length in 1..80) { "Batch name must be 1–80 characters." }
      require(batchSubtitle.length <= 160) { "Batch subtitle must be 160 characters or fewer." }
      require(subjectName.length in 1..100) { "Subject name must be 1–100 characters." }
      require(lectureTitle.length in 1..150) { "Lecture title must be 1–150 characters." }
      require(
        videoUrl.length <= 1000 &&
          engNotesUrl.length <= 1000 &&
          hinNotesUrl.length <= 1000 &&
          pptUrl.length <= 1000
      ) { "Links must be 1000 characters or fewer." }

      val userRef = db.collection("users").document(uid)
      val writeBatch = db.batch()

      val existingBatch = currentBatches.firstOrNull { it.name.equals(batchName, ignoreCase = true) }
      val batchId = existingBatch?.id ?: userRef.collection("batches").document().id
      if (existingBatch == null) {
        val batchRef = userRef.collection("batches").document(batchId)
        val nextSortOrder = ((currentBatches.maxOfOrNull { it.sortOrder } ?: -1L) + 1L)
          .coerceAtMost(10000L)
        writeBatch.set(
          batchRef,
          mapOf(
            "userId" to uid,
            "name" to batchName,
            "subtitle" to batchSubtitle,
            "sortOrder" to nextSortOrder,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }

      val existingSubject = currentSubjects.firstOrNull {
        it.batchId == batchId && it.name.equals(subjectName, ignoreCase = true)
      }
      val subjectId = existingSubject?.id ?: userRef.collection("subjects").document().id
      if (existingSubject == null) {
        val subjectRef = userRef.collection("subjects").document(subjectId)
        val nextSubOrder = ((currentSubjects.filter { it.batchId == batchId }
          .maxOfOrNull { it.sortOrder } ?: -1L) + 1L).coerceAtMost(10000L)
        writeBatch.set(
          subjectRef,
          mapOf(
            "userId" to uid,
            "batchId" to batchId,
            "name" to subjectName,
            "sortOrder" to nextSubOrder,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }

      val lectureRef = userRef.collection("lectures").document()
      opPath = lectureRef.path
      writeBatch.set(
        lectureRef,
        mapOf(
          "userId" to uid,
          "batchId" to batchId,
          "subjectId" to subjectId,
          "title" to lectureTitle,
          "videoUrl" to videoUrl,
          "engNotesUrl" to engNotesUrl,
          "hinNotesUrl" to hinNotesUrl,
          "pptUrl" to pptUrl,
          "completed" to false,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        ),
      )

      writeBatch.commit().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, opPath)
      Result.failure(e)
    }
  }

  suspend fun toggleLectureCompleted(
    userId: String,
    lectureId: String,
    completed: Boolean,
  ): Result<Unit> {
    val docPath = "users/$userId/lectures/$lectureId"
    return try {
      val uid = requireUserId(userId)
      require(lectureId.isNotBlank()) { "Lecture ID must not be blank." }
      db.collection("users").document(uid)
        .collection("lectures").document(lectureId)
        .update(
          mapOf(
            "completed" to completed,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun deleteLecture(
    userId: String,
    lectureId: String,
  ): Result<Unit> {
    val docPath = "users/$userId/lectures/$lectureId"
    return try {
      val uid = requireUserId(userId)
      require(lectureId.isNotBlank()) { "Lecture ID must not be blank." }
      db.collection("users").document(uid)
        .collection("lectures").document(lectureId)
        .delete()
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docPath)
      Result.failure(e)
    }
  }

  suspend fun saveSocialLinks(
    userId: String,
    whatsappInput: String,
    telegramInput: String,
  ): Result<Unit> {
    val docPath = "users/$userId/settings/preferences"
    return try {
      val uid = requireUserId(userId)
      val normalizedWa = normalizeWhatsAppUrl(whatsappInput)
      val normalizedTg = normalizeTelegramUrl(telegramInput)
      require(normalizedWa.length <= 500 && normalizedTg.length <= 500) {
        "Social link URL must be 500 characters or fewer."
      }

      val prefsRef = db.collection("users").document(uid)
        .collection("settings").document("preferences")
      val existing = prefsRef.get().await()
      if (existing.exists()) {
        prefsRef.update(
          mapOf(
            "whatsappUrl" to normalizedWa,
            "telegramUrl" to normalizedTg,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      } else {
        prefsRef.set(
          mapOf(
            "userId" to uid,
            "whatsappUrl" to normalizedWa,
            "telegramUrl" to normalizedTg,
            "seededDefaults" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docPath)
      Result.failure(e)
    }
  }

  suspend fun verifyOrSetAdminPassword(
    userId: String,
    passwordInput: String,
    configuredSecretPassword: String,
  ): Result<Boolean> {
    val docPath = "users/$userId/settings/preferences"
    return try {
      val uid = requireUserId(userId)
      val trimmed = passwordInput.trim()
      if (trimmed.isEmpty()) {
        return Result.success(false)
      }
      if (configuredSecretPassword.isNotBlank()) {
        return Result.success(trimmed == configuredSecretPassword)
      }

      val prefsRef = db.collection("users").document(uid)
        .collection("settings").document("preferences")
      val snapshot = prefsRef.get().await()
      val incomingHash = sha256Hex(trimmed)
      val existingHash = snapshot.getString("adminPasscodeHash").orEmpty()

      if (existingHash.isNotBlank()) {
        Result.success(incomingHash == existingHash)
      } else {
        if (trimmed.length < 6) {
          throw IllegalArgumentException("Admin password must be at least 6 characters.")
        }
        if (snapshot.exists()) {
          prefsRef.update(
            mapOf(
              "adminPasscodeHash" to incomingHash,
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          ).await()
        } else {
          prefsRef.set(
            mapOf(
              "userId" to uid,
              "whatsappUrl" to "https://whatsapp.com",
              "telegramUrl" to "https://telegram.org",
              "seededDefaults" to false,
              "adminPasscodeHash" to incomingHash,
              "createdAt" to FieldValue.serverTimestamp(),
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          ).await()
        }
        Result.success(true)
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docPath)
      Result.failure(e)
    }
  }

  private fun logFlowError(
    error: Throwable,
    operationType: OperationType,
    path: String,
    uid: String,
  ) {
    val firestoreError = generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()
    if (firestoreError == null && error is CancellationException) throw error
    val exceptionToLog = firestoreError ?: (error as? Exception)
    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
      handleFirestoreError(exceptionToLog, operationType, path)
    }
  }

  private fun slugify(raw: String): String =
    raw.lowercase()
      .replace(Regex("[^a-z0-9]+"), "_")
      .trim('_')
      .ifBlank { "item" }

  private fun sha256Hex(input: String): String {
    val digest = java.security.MessageDigest.getInstance("SHA-256")
      .digest(input.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }

  companion object {
    fun normalizeWhatsAppUrl(raw: String): String {
      val trimmed = raw.trim()
      if (trimmed.isBlank()) return "https://whatsapp.com"
      if (trimmed.startsWith("http://", ignoreCase = true) ||
        trimmed.startsWith("https://", ignoreCase = true)
      ) {
        return trimmed
      }
      val digits = trimmed.replace(Regex("[^0-9]"), "")
      return if (digits.isNotEmpty()) "https://wa.me/$digits" else "https://whatsapp.com"
    }

    fun normalizeTelegramUrl(raw: String): String {
      val trimmed = raw.trim()
      if (trimmed.isBlank()) return "https://telegram.org"
      if (trimmed.startsWith("http://", ignoreCase = true) ||
        trimmed.startsWith("https://", ignoreCase = true)
      ) {
        return trimmed
      }
      val handle = trimmed.removePrefix("@").trim()
      return if (handle.isNotEmpty()) "https://t.me/$handle" else "https://telegram.org"
    }
  }
}
